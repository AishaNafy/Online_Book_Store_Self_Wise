package com.Items;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/insertItem")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                 maxFileSize = 1024 * 1024 * 10,      // 10MB
                 maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class insertItem extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Define the directory where uploaded files will be saved
    private static final String UPLOAD_DIRECTORY = "images";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String itemName = request.getParameter("itemName");
        String description = request.getParameter("description");
        double price = Double.parseDouble(request.getParameter("price"));
        
        // Retrieve image part
        Part filePart = request.getPart("itemImage");
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        
        // Define the upload path where the image will be saved
        String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY;
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir(); // Create the directory if it does not exist
        
        // Save the file to the server
        String filePath = uploadPath + File.separator + fileName;
        filePart.write(filePath);

        // Store the relative path in the database
        String relativePath = UPLOAD_DIRECTORY + File.separator + fileName;
        boolean isTrue = ItemsDBUtil.insertItem(itemName, description, relativePath, price);
        

        if (isTrue) {
            System.out.println("Image Path Saved: " + relativePath);

            response.sendRedirect(request.getContextPath() + "/AdminViewServlet");
        } else {
            RequestDispatcher dis = request.getRequestDispatcher("Unsuccess.jsp");
            dis.forward(request, response);
        }
    }
}
